ProjectHologram

Create Hologram(s)
	*Search "NameMe" in The Creative Inventory.
	*It Will be a Blue Spawn Egg.
	*Rename IT to Desired Hologram TEXT.
	*Spawn At Choosen Location.

Remove Hologram(s)
	*/function remove_hologram(Stand Within 3 Blocks of Hologram(s) Location) 

Enable/Disable Command Feedback In Chat With the Following Functions:
	*/function enable_feedback
	*/function disable_feedback
	
	By AnimeSam